@ECHO OFF

REG EXPORT "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup" %WINDIR%\InstallWDS.reg /y
REG ADD "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup" /v "SourcePath" /t REG_SZ /d "\\SERVERNAME\SHARE" /f
REG ADD "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup" /v "ServicePackSourcePath" /t REG_SZ /d "\\SERVERNAME\SHARE" /f

VER | Find "Microsoft Windows [Version 5.2." > nul
If %ERRORLEVEL% == 0 GoTo Win2003 
VER | Find "Microsoft Windows [Version 6.0." > nul
If %ERRORLEVEL% == 0 GoTo Win2008 

GoTo CleanUp

:Win2003
ECHO [Components] > %WINDIR%\InstallWDS.inf
ECHO RemInst = on >> %WINDIR%\InstallWDS.inf
Sysocmgr.exe /i:sysoc.inf /u:%WINDIR%\InstallWDS.inf
GoTo CleanUp

:Win2008
ServerManagerCmd -install WDS
GoTo CleanUp

:CleanUp
REG IMPORT %WINDIR%\InstallWDS.reg
DEL %WINDIR%\InstallWDS.inf
DEL %WINDIR%\InstallWDS.reg
