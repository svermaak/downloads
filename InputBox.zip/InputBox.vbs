Option Explicit

On Error Resume Next

Dim varInput
Dim varShell
Dim varSendTo
Dim varPrompt
Dim varTitle
Dim varDefault

WScript.Echo ""
WScript.Echo "InputBox v1.00 by Shaun Vermaak {22E1AA44-6A30-4e11-9F6E-45CD0A627B5C}"
WScript.Echo ""

varSendTo = Wscript.Arguments.Named("SendTo")
varPrompt = Wscript.Arguments.Named("Prompt")
varTitle = Wscript.Arguments.Named("Title")

If Len(Trim(varSendTo)) > 0 Then
    varInput = InputBox(varPrompt, varTitle, varDefault)
    Set varShell = WScript.CreateObject("WScript.Shell")
    varShell.Run varSendTo & " """ & varInput & """"
Else
    WScript.Echo "Usage:	CScript.exe //NOLOGO InputBox.vbs /SendTo:SOMEAPP.BAT /prompt:""YOUR PROMPT GOES HERE"" /title:""YOUR TITLE GOES HERE"""
    WScript.Echo ""
    WScript.Echo "Example:	CScript.exe //NOLOGO InputBox.vbs /SendTo:RUN.BAT /prompt:""Please enter you name"" /title:""Name"""
End If
