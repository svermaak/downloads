Option Explicit

On Error Resume Next

Dim strCommand
Dim strSuccessCodes

strCommand = WScript.Arguments.Named("Command")
strSuccessCodes = WScript.Arguments.Named("SuccessCodes")

If Len(Trim(strCommand)) = 0 Or Len(Trim(strSuccessCodes)) = 0 Then
    WScript.Quit(1)
End If

Dim arrSuccessCodes
Dim intSuccessCode

arrSuccessCodes = Split(strSuccessCodes,";")

Dim objShell
Dim objExec
Dim intReturnCode

Set objShell = CreateObject("WScript.Shell")

Err.Clear
Set objExec = objShell.Exec(strCommand)
If Err.Number <> 0 Then
    WScript.Echo "Problem with command"
    WScript.Quit(1)
End If

Do While objExec.Status = 0
    Call WScript.Sleep(100)
Loop

intReturnCode = objExec.ExitCode

For Each intSuccessCode In arrSuccessCodes
    If IsNumeric(intSuccessCode) Then
        If intReturnCode = CInt(intSuccessCode) Then
            WScript.Echo "Success"
            intReturnCode = 0
            Exit For
        End If
    End If
Next

Set objExec = Nothing
Set objShell = Nothing

WScript.Echo intReturnCode

Call WScript.Quit(intReturnCode)
