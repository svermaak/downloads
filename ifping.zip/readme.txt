IFPING v1.01 (C) AnyKey Software 2005 - www.anykeyonline.nl
###########################################################

IFPING is a Windows based commandline utility that checks if a specified host is reachable and then returns the ERRORLEVEL value back to the CMD.

If you use batch files to connect network drives with the NET USE command their is no way to test if the 'server' is connectable via the network before running the NET USE commands.

Since failing NET USE commands take a long time it would be usefull to test connection before attemting to NET USE the shares.

This IFPING tool will only PING the 'server' it will not test for SMB connection.

Have fun IFPING-ing.

USAGE
#####
IFPING v1.1 (C) AnyKey Software 2006 - www.anykeyonline.nl

Usage : IFPING 10.0.0.1 [wu[:xx]/wd[:xx]] /S
        Returns: errorlevel 0 (ping successful)
        Returns: errorlevel 1 (ping unsuccessful)

Optional second parameter WU or WD.
        WU[:xx] = Wait Up, wait for host to come up
        WD[:xx] = Wait Down, wait for host to go down
                  Test xx times, then exit regardles of outcome

Optional /S     = Silent, no display output

note.   ===> New in v1.11, 10 pings are done every round, <===
        ===> more then half should be up, for up status.  <===


Revision History
################
v1.1  New parameters enables timeout on WU and WD
      Silent parameter added for invisable operation
v1.01 Doing 10 pings per round, and only return hot when more then half is replied.
      Add Wait for Up, and Wait for Down options.

v1.0  First public release
 

Known Issues
############
A regular PING can have multiple results, if you get the result:
C:\>PING 10.1.1.1
Reply from 1.2.3.4: Destination net unreachable.

IFPING will return that the server is connectable. The PING result code is the same. I hope to figure this one out in future versions. Note, this might also be a routing configuration problem in your network.

Only when the result is:
C:\>PING 10.1.1.1
Request timed out.
Then IFPING will return unconnectable.

Disclaimer
##########
This utility is distributed "as is" and without warranties as to performance, accuracy, or any other warranties whether expressed or implied. The author is not responsible for any costs or damages incurred, whether incidental or consequential, by the use or misuse of this utility.
