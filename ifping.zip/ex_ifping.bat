@ECHO OFF
ECHO This batch file demonstrates the functionality of IFPING.EXE
ECHO.


ifping %1

echo.
echo Batch file continueing
echo Errorlevel: %ERRORLEVEL%

if %ERRORLEVEL%==0 goto ONLINE

goto OFFLINE

:OFFLINE
ECHO Host not pingable.
GOTO THEEND

:ONLINE
ECHO Host replied successfully.
REM net use K: \\server\share
GOTO THEEND


:THEEND
ECHO.
ECHO Done.
ECHO.