' //***************************************************************************
' // ***** Script Header *****
' //
' // Solution:  REG
' // File:      Reg.vbs
' // Author:    Shaun Vermaak
' // Purpose:   VBS implementation of REG.exe for use in GPOs
' //
' //
' // Usage:     REG.vbs /Action:ADD|/Action:DELETE /Key:REGISTRYKEY [/Value:REGISTRYVALUE] [/DATA:REGISTRYVALUEDATA] [/TYPE:REGISTRYVALUETYPE]
' // Examples:
' // REG.vbs /Action:Add /Key:HKLM\SOFTWARE\NewKey
' // REG.vbs /Action:Add /Key:HKLM\SOFTWARE\NewKey /Value:New_REG_SZ /Data:Value /Type:REG_SZ
' // REG.vbs /Action:Add /Key:HKLM\SOFTWARE\NewKey /Value:New_REG_Binary /Data:"0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0" /Type:REG_BINARY
' // REG.vbs /Action:Add /Key:HKLM\SOFTWARE\NewKey /Value:New_REG_DWORD /Data:0 /Type:REG_DWORD
' // REG.vbs /Action:Add /Key:HKLM\SOFTWARE\NewKey /Value:New_REG_EXPAND_SZ /Data:Value /Type:REG_EXPAND_SZ
' // REG.vbs /Action:Add /Key:HKLM\SOFTWARE\NewKey /Value:New_REG_MULTI_SZ /Data:"Value1,Value2,Value3" /Type:REG_MULTI_SZ
' // REG.vbs /Action:Delete /Key:HKLM\SOFTWARE\NewKey /Value:New_REG_SZ
' // REG.vbs /Action:Delete /Key:HKLM\SOFTWARE\NewKey
' //
' //
' // REG History:
' // 0.0.1	2010/09/01	Created initial version.
' //
' //
' // ***** End Header *****
' //***************************************************************************

Option Explicit

On Error Resume Next

Const HKEY_CLASSES_ROOT = &H80000000
Const HKEY_CURRENT_USER = &H80000001
Const HKEY_LOCAL_MACHINE = &H80000002
Const HKEY_USERS = &H80000003
Const HKEY_CURRENT_CONFIG = &H80000005

Dim varAction
Dim varKeyPath
Dim varValueName
Dim varValueData
Dim varValueDataType
Dim varHive
Dim objRegistry
Dim arrValueData

varAction = Wscript.Arguments.Named("Action")
varKeyPath = Wscript.Arguments.Named("Key")
varValueName = Wscript.Arguments.Named("Value")
varValueData = Wscript.Arguments.Named("Data")
varValueDataType = Wscript.Arguments.Named("Type")

If Len(Trim(varAction)) <> 0 And Len(Trim(varKeyPath)) <> 0 Then

    varHive = Left(varKeyPath,InStr(1,varKeyPath,"\")-1)
    varKeyPath = Right(varKeyPath,Len(varKeyPath)-Len(varHive)-1)

    Select Case varHive
    Case "HKCR"
        varHive = HKEY_CLASSES_ROOT
    Case "HKEY_CLASSES_ROOT"
        varHive = HKEY_CLASSES_ROOT
    Case "HKCU"
        varHive = HKEY_CURRENT_USER
    Case "HKEY_CURRENT_USER"
        varHive = HKEY_CURRENT_USER
    Case "HKLM"
        varHive = HKEY_LOCAL_MACHINE
    Case "HKEY_LOCAL_MACHINE"
        varHive = HKEY_LOCAL_MACHINE
    Case "HKU"
        varHive = HKEY_USERS
    Case "HKEY_USERS"
        varHive = HKEY_USERS
    Case "HKCC"
        varHive = HKEY_CURRENT_CONFIG
    Case "HKEY_CURRENT_CONFIG"
        varHive = HKEY_CURRENT_CONFIG
    End Select

    Set objRegistry = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\default:StdRegProv")

    Select Case UCase(Trim(varAction))
    Case "ADD"
        If Len(Trim(varValueName)) <> 0 And Len(Trim(varValueData)) <> 0 And Len(Trim(varValueDataType)) <> 0 Then
            Select Case UCase(Trim(varValueDataType))
            Case "REG_SZ"
                objRegistry.SetStringValue varHive,varKeyPath,varValueName,varValueData
            Case "REG_BINARY"
                arrValueData=Split(varValueData,",")
                objRegistry.SetBinaryValue varHive,varKeyPath,varValueName,arrValueData
            Case "REG_DWORD"
                objRegistry.SetDWORDValue varHive,varKeyPath,varValueName,varValueData
            Case "REG_EXPAND_SZ"
                objRegistry.SetExpandedStringValue varHive,varKeyPath,varValueName,varValueData
            Case "REG_MULTI_SZ"
                arrValueData=Split(varValueData,",")
                objRegistry.SetMultiStringValue varHive,varKeyPath,varValueName,arrValueData
            End Select
        Else
            objRegistry.CreateKey varHive,varKeyPath
        End If
    Case "DELETE"
        If Len(Trim(varValueName)) <> 0 Then
            objRegistry.DeleteValue varHive,varKeyPath,varValueName
        Else
            objRegistry.DeleteKey varHive,varKeyPath
        End If
    Case Else
        'Nothing
    End Select

    Set objRegistry = Nothing
End If