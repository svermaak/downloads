@Echo Off

SET rnd=%random%

REM ECHO %rnd:~5,1%
REM ECHO %rnd:~4,1%
REM ECHO %rnd:~3,1%
REM ECHO %rnd:~2,1%
REM ECHO %rnd:~1,1%
REM ECHO %rnd:~0,1%

IF NOT '%rnd:~5,1%'=='' SET rnd1=%rnd:~5,1%& SET rnd2=%rnd:~4,1%& GOTO BUILD
IF NOT '%rnd:~4,1%'=='' SET rnd1=%rnd:~4,1%& SET rnd2=%rnd:~3,1%& GOTO BUILD
IF NOT '%rnd:~3,1%'=='' SET rnd1=%rnd:~3,1%& SET rnd2=%rnd:~2,1%& GOTO BUILD
IF NOT '%rnd:~2,1%'=='' SET rnd1=%rnd:~2,1%& SET rnd2=%rnd:~1,1%& GOTO BUILD
IF NOT '%rnd:~1,1%'=='' SET rnd1=%rnd:~1,1%& SET rnd2=%rnd:~0,1%& GOTO BUILD
IF NOT '%rnd:~0,1%'=='' SET rnd1=%rnd:~0,1%& SET rnd2=0& GOTO BUILD

:BUILD
REM ECHO %rnd%
REM  ECHO %rnd2%%rnd1%

GOTO %rnd2%%rnd1%


Goto END

:00
Color 0A
Goto END

:01
Color 0B
Goto END

:02
Color 0C
Goto END

:03
Color 0D
Goto END

:04
Color 0E
Goto END

:05
Color 1A
Goto END

:06
Color 1B
Goto END

:07
Color 1C
Goto END

:08
Color 1D
Goto END

:09
Color 1E
Goto END

:10
Color 1F
Goto END

:11
Color 27
Goto END

:12
Color 2B
Goto END

:13
Color 2E
Goto END

:14
Color 2F
Goto END

:15
Color 37
Goto END

:16
Color 3A
Goto END

:17
Color 3B
Goto END

:18
Color 3E
Goto END

:19
Color 3F
Goto END

:20
Color 47
Goto END

:21
Color 4A
Goto END

:22
Color 4B
Goto END

:23
Color 4D
Goto END

:24
Color 4E
Goto END

:25
Color 4F
Goto END

:26
Color 57
Goto END

:27
Color 5A
Goto END

:28
Color 5B
Goto END

:29
Color 5C
Goto END

:30
Color 5E
Goto END

:31
Color 60
Goto END

:32
Color 64
Goto END

:33
Color 67
Goto END

:34
Color 69
Goto END

:35
Color 6A
Goto END

:36
Color 6E
Goto END

:37
Color 6F
Goto END

:38
Color 70
Goto END

:39
Color 72
Goto END

:40
Color 74
Goto END

:41
Color 75
Goto END

:42
Color 79
Goto END

:43
Color 7C
Goto END

:44
Color 80
Goto END

:45
Color 84
Goto END

:46
Color 87
Goto END

:47
Color 8E
Goto END

:48
Color 8F
Goto END

:49
Color 97
Goto END

:50
Color 9A
Goto END

:51
Color 9B
Goto END

:52
Color 9E
Goto END

:53
Color 9F
Goto END

:54
Color A0
Goto END

:55
Color A1
Goto END

:56
Color A4
Goto END

:57
Color A9
Goto END

:58
Color AC
Goto END

:59
Color AD
Goto END

:60
Color B0
Goto END

:61
Color B1
Goto END

:62
Color B4
Goto END

:63
Color B5
Goto END

:64
Color B9
Goto END

:65
Color BC
Goto END

:66
Color BD
Goto END

:67
Color C0
Goto END

:68
Color C1
Goto END

:69
Color C5
Goto END

:70
Color C7
Goto END

:71
Color CB
Goto END

:72
Color CE
Goto END

:73
Color CF
Goto END

:74
Color D0
Goto END

:75
Color D1
Goto END

:76
Color D4
Goto END

:77
Color D9
Goto END

:78
Color DA
Goto END

:79
Color DB
Goto END

:80
Color DE
Goto END

:81
Color DF
Goto END

:82
Color E0
Goto END

:83
Color E1
Goto END

:84
Color E2
Goto END

:85
Color E3
Goto END

:86
Color E4
Goto END

:87
Color E5
Goto END

:88
Color E9
Goto END

:89
Color EC
Goto END

:90
Color ED
Goto END

:91
Color F0
Goto END

:92
Color F1
Goto END

:93
Color F2
Goto END

:94
Color F3
Goto END

:95
Color F4
Goto END

:96
Color F5
Goto END

:97
Color F9
Goto END

:98
Color FC
Goto END

:99
Color FD
Goto END

:END
REM cls
