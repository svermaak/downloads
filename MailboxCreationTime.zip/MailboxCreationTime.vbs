'MailboxCreationTime v1.00 by Shaun Vermaak {22E1AA44-6A30-4e11-9F6E-45CD0A627B5C}")

Option Explicit

Const PR_NTSDModificationTime = &H3FD60040

Dim strServerName
Dim objFSO
Dim objOutputFile
Dim objRootDSE
Dim strNamingContext
Dim strDefaultNamingContext
Dim objConnection
Dim objCommand
Dim strCommandText
Dim objRecordSet1
Dim objRecordSet2

strServerName = Trim(WScript.Arguments.Named("ServerName"))

If strServerName <> "" Then

    Set objFSO = CreateObject("Scripting.FileSystemObject")

    Set objOutputFile = objFSO.OpenTextFile(".\" & strServerName & ".txt",2,True)

    objOutputFile.WriteLine("ServerName" & vbTab & "DisplayName" & vbTab & "MailboxAlias" & vbTab & "CreationTime")

    Set objRootDSE = GetObject("LDAP://RootDSE")
    strNamingContext = objRootDSE.Get("configurationNamingContext")
    strDefaultNamingContext = objRootDSE.Get("defaultNamingContext")

    Set objConnection = CreateObject("ADODB.Connection")
    Set objCommand = CreateObject("ADODB.Command")

    objConnection.Provider = "ADsDSOObject"
    objConnection.Open "ADs Provider"

    strCommandText = "<LDAP://" & strNamingContext & ">;(&(objectCategory=msExchExchangeServer)(cn=" & strServerName & "));cn,name,legacyExchangeDN;subtree"
    objCommand.ActiveConnection = objConnection
    objCommand.CommandText = strCommandText
    Set objRecordSet1 = objCommand.Execute

    While Not objRecordSet1.EOF
        strCommandText  = "<LDAP://" & strDefaultNamingContext & ">;(&(&(&(&(mailnickname=*)(!msExchHideFromAddressLists=TRUE)(|(&(objectCategory=person)(objectClass=user)(msExchHomeServerName=" & objRecordSet1.Fields("legacyExchangeDN") & ")) )))));mail,distinguishedName,mailnickname;subtree" & ";mail,displayname,mailnickname;subtree"
        objCommand.Properties("Page Size") = 1000
        objCommand.CommandText = strCommandText
        Set objRecordSet2 = objCommand.Execute
            While Not objRecordSet2.EOF
                Call ProcessMailbox(strServerName,objRecordSet2.Fields("mail"),objRecordSet2.Fields("displayname"))
            objRecordSet2.MoveNext
            WEnd
        objRecordSet1.MoveNext
    WEnd

    objRecordSet1.Close
    objOutputFile.Close
    Set objFSO = Nothing
    Set objConnection = Nothing
    Set objCommand = Nothing
Else
    WScript.Echo "Usage: CSCript MailboxCreationTime.vbs /ServerName:SERVERNAME"
End If

Sub ProcessMailbox(strServerName,strMailboxAlias,strDisplayName)
    Dim objMAPISession
    Dim objInbox
    Dim objInfoStore
    Dim objRootFolder
    Dim objNonIPMRootFolder
    Dim intCommaCnt
    Dim strFirstName
    Dim strLastName
    Dim intPos1
    Dim intPos2
    Dim strSuffixName
    Dim strCreationTime

    On Error Resume Next
    Set objMAPISession = CreateObject("MAPI.Session")
    Err.Clear

    objMAPISession.Logon "","",False,True,True,True,strServerName & vbLF & strMailboxAlias

    If Err.Number = 0 Then
        Err.Clear

        Set objInbox = objMAPISession.Inbox
        Set objInfoStore = objMAPISession.GetInfoStore(objInbox.StoreID)
        Set objRootFolder = objInfostore.Rootfolder
        Set objNonIPMRootFolder = objMAPISession.GetFolder(objRootFolder.Fields.Item(&h0E090102),objInfoStore.ID)

        strCreationTime = objNonIPMRootFolder.Fields.Item(PR_NTSDModificationTime)

        On Error Goto 0

        If Err.Number = 0 Then
            intCommaCnt = UBound(Split(LCase(strDisplayName), ","))

            If intCommaCnt = 1 Then
                intPos1 = InStr(1,strDisplayName,",",1)
                strFirstName = Right(strDisplayName, (Len(strDisplayName)-(intPos1+1)))
                strLastName = Left(strDisplayName,(intPos1-1))
                strDisplayName = strFirstName & " " & strLastName
            ElseIf intCommaCnt = 2 Then
                intPos1 = InStr(1,strDisplayName,",",1)
                intPos2 = InStr((intPos1+1),strDisplayName,",",1)
                strFirstName = Mid(strDisplayName,(intPos1+2),((intPos2-intPos1)-2))
                strLastName = Left(strDisplayName,(intPos1-1))
                strSuffixName = Right(strDisplayName,(Len(strDisplayName)-(intPos2+1)))
                strDisplayName = strFirstName & " " & strLastName & " " & strSuffixName
            End If
            objOutputFile.WriteLine(strServerName & vbTab & strDisplayName & vbTab & strMailboxAlias & vbTab & strCreationTime)
        Else
            objOutputFile.WriteLine(strServerName & vbTab & "Unknown" & vbTab & strMailboxAlias & vbTab & "Error Opening Mailbox") 
        End If
    Else
        objOutputFile.WriteLine(strServerName & vbTab & "Unknown" & vbTab & strMailboxAlias & vbTab & "Error Opening Mailbox") 
    End If

    Set objMAPISession = Nothing
    Set objInbox = Nothing
    Set objInfoStore = Nothing
    Set objRootFolder = Nothing
    Set objNonIPMRootFolder = Nothing
End Sub