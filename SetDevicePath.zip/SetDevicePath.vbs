'SetDevicePath v1.00 by Shaun Vermaak {22E1AA44-6A30-4e11-9F6E-45CD0A627B5C}")

Option Explicit

Const HKEY_LOCAL_MACHINE = &H80000002
Const FOR_READING = 1

Dim objFSO
Dim strFolder
Dim objReg
Dim strKeyPath
Dim strValueName
Dim strValue
Dim strDevicePath
Dim objFolder
Dim colFiles
Dim objFile
Dim strFolderPath

Set objFSO = CreateObject("Scripting.FileSystemObject")

strFolder = Wscript.Arguments.Named("DriverFolder")

If objFSO.FolderExists(strFolder) = True Then

    Set objReg = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\default:StdRegProv")

    strKeyPath = "SOFTWARE\Microsoft\Windows\CurrentVersion"
    strValueName = "DevicePath"
    objReg.GetExpandedStringValue HKEY_LOCAL_MACHINE,strKeyPath,strValueName,strValue

    strDevicePath = strValue
    strDevicePath = ReplaceWithVariables(strDevicePath, "WinDir")
    strDevicePath = ReplaceWithVariables(strDevicePath, "SystemDrive")

    Set objFolder = objFSO.GetFolder(strFolder)

    Set colFiles = objFolder.Files
    For Each objFile In colFiles
        If Right(UCase(objFile.Path),4)=".INF" Then
            strFolderPath = ReplaceWithVariables(objFolder.Path, "WinDir")
            strFolderPath = ReplaceWithVariables(objFolder.Path, "SystemDrive")
            If InStr(strDevicePath,";" & strFolderPath & ";") = 0 And Right(strDevicePath,Len(strFolderPath)) <> strFolderPath Then
                If Len(strDevicePath) > 0 Then
                    strDevicePath = strDevicePath & ";" & strFolderPath
                Else
                    strDevicePath = strFolderPath
                End If
            End If
        End If
    Next

    ShowSubFolders(objFolder)
 
    WScript.Echo strDevicePath
    objReg.SetExpandedStringValue HKEY_LOCAL_MACHINE,strKeyPath,strValueName,strDevicePath

    Set objFSO = Nothing
    Set objReg = Nothing
End If

Sub ShowSubFolders(objFolder)
    Dim colFolders
    Dim objSubFolder
    Dim strSubFolderPath

    Set colFolders = objFolder.SubFolders

    For Each objSubFolder In colFolders
        Set colFiles = objSubFolder.Files

        For Each objFile In colFiles
            If Right(UCase(objFile.Path),4)=".INF" Then
                strSubFolderPath = ReplaceWithVariables(objSubFolder.Path, "WinDir")
                strSubFolderPath = ReplaceWithVariables(objSubFolder.Path, "SystemDrive")
                If InStr(strDevicePath,";" & strSubFolderPath & ";") = 0 And Right(strDevicePath,Len(strSubFolderPath)) <> strSubFolderPath Then
                    If Len(strDevicePath) > 0 Then
                        strDevicePath = strDevicePath & ";" & strSubFolderPath
                    Else
                        strDevicePath = strSubFolderPath
                    End If
                End If
            End If
        Next
        ShowSubFolders(objSubFolder)
    Next
End Sub

Function ReplaceWithVariables(strPath, strVariable)
    Dim objShell
    Dim strValue

    strVariable = UCase(Replace(strVariable, "%", ""))

    Set objShell = CreateObject( "WScript.Shell" )

    strValue = objShell.ExpandEnvironmentStrings("%" & strVariable & "%")
    strPath = Replace(UCase(strPath), UCase(strValue), "%" & strVariable & "%")

    Set objShell = Nothing

    ReplaceWithVariables = strPath
End Function