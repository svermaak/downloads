Option Explicit

On Error Resume Next

Dim objCommand
Dim objConnection
Dim objRootDSE
Dim strDNSDomain
Dim strBase
Dim objSystemInfo
Dim strDomain
Dim strFilter
Dim strAttributes
Dim strQuery
Dim objRecordset
Dim strUserName
Dim strCN
Dim objUser
Dim arrproxyAddresses
Dim strproxyAddresses

Set objCommand = CreateObject("ADODB.Command")
Set objConnection = CreateObject("ADODB.Connection")

objConnection.Provider = "ADsDSOObject"
objConnection.Open "Active Directory Provider"
objCommand.ActiveConnection = objConnection

Set objRootDSE = GetObject("LDAP://RootDSE")

strDNSDomain = objRootDSE.Get("defaultNamingContext")
strBase = "<LDAP://" & strDNSDomain & ">" 

Set objSystemInfo = CreateObject("ADSystemInfo") 
strDomain = objSystemInfo.DomainShortName

strFilter = "(&(objectCategory=Person)(objectClass=User))"

strAttributes = "sAMAccountName,cn,proxyAddresses"

strQuery = strBase & ";" & strFilter & ";" & strAttributes & ";subtree"
objCommand.CommandText = strQuery
objCommand.Properties("Page Size") = 100
objCommand.Properties("Timeout") = 30
objCommand.Properties("Cache Results") = False

Set objRecordset = objCommand.Execute

Do Until objRecordset.EOF
    strUserName = objRecordset.Fields("sAMAccountName").Value
    strCN = objRecordset.Fields("cn").value
    arrproxyAddresses = objRecordset.Fields("proxyAddresses").value
    If IsArray(arrproxyAddresses) = True Then
        For Each strproxyAddresses In arrproxyAddresses
            WScript.Echo strUserName & vbTab & strproxyAddresses
        Next
    End If
    objRecordset.MoveNext
Loop

objRecordset.Close
objConnection.Close

set objUser = Nothing
Set objRecordset = Nothing
Set objSystemInfo = Nothing
Set objRootDSE = Nothing
Set objConnection = Nothing
Set objCommand = Nothing
