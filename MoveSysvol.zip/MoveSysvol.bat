REM Automated by Shaun Vermaak {22E1AA44-6A30-4e11-9F6E-45CD0A627B5C} downloaded from ITtelligence.co.za
REM Move Sysvol location (as per http://support.microsoft.com/kb/842162)
REM The following must be in working folder or in path:
REM MoveSysvol.bat
REM SetFRS.vbs
REM sysvol.inf
REM linkd.exe (Not included)
REM robocopy.exe (Not included)
REM Usage: MoveSysvol.bat OLDSYSVOLPATH NEWSYSVOLPATH DOMAINFQDN
REM Example: MoveSysvol.bat C:\Windows\SYSVOL D:\SYSVOL TESTDOMAIN.COM

@Echo Off

sc config NtFrs start= Disabled
net stop NtFrs

robocopy "%1" "%2" /zb /e /XD %3
md "%2\staging areas\%3"
md "%2\sysvol\%3"

REG ADD "HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" /v SysVol /d %2\sysvol /t REG_SZ /f
REG ADD "HKLM\SYSTEM\CurrentControlSet\Services\NtFrs\Parameters\Backup/Restore\Process at Startup" /v BurFlags /d 210 /t REG_DWORD /f

Set Sysvol=%2

Copy sysvol.inf %systemroot%\security\templates
secedit /configure /cfg %systemroot%\security\templates\sysvol.inf /db %systemroot%\security\templates\sysvol.db /overwrite /quiet

linkd "%2\sysvol\saps.gov.za" "%2\domain"
linkd "%2\staging areas\saps.gov.za" "%2\staging\domain"

cscript //nologo SetFRS.vbs /DomainController:%COMPUTERNAME% /NewSysvolPath:%2

sc config NtFrs start= Auto
net start NtFrs
