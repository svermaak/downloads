Option Explicit

Dim strDomainController
Dim strNewSysvolPath
Dim objSysvol

strDomainController = Wscript.Arguments.Named("DomainController")
strNewSysvolPath = Wscript.Arguments.Named("NewSysvolPath")

If Len(Trim(strDomainController)) <> 0 And Len(Trim(strNewSysvolPath)) Then
    Set objSysvol = GetObject("LDAP://CN=Domain System Volume (SYSVOL share),CN=NTFRS Subscriptions,CN=" & strDomainController & ",OU=Domain Controllers,DC=saps,DC=gov,DC=za")
 
    objSysvol.Put "fRSRootPath", strNewSysvolPath & "\domain"
    objSysvol.Put "fRSStagingPath", strNewSysvolPath & "\staging\domain"
    objSysvol.SetInfo

    Set objSysvol = Nothing
End If
