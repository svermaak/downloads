Option Explicit

Dim strDomainController
Dim strNewSysvolPath
Dim strDomain
Dim objSysvol
Dim strDN

strDomainController = Wscript.Arguments.Named("DomainController")
strNewSysvolPath = Wscript.Arguments.Named("NewSysvolPath")
strDomain = Wscript.Arguments.Named("FQDN")

If Len(Trim(strDomainController)) <> 0 And Len(Trim(strNewSysvolPath)) <> 0 And Len(Trim(strDomain)) <> 0 Then
    strDN = "DC=" & Replace(strDomain,".",",DC=")
    Set objSysvol = GetObject("LDAP://CN=SYSVOL Subscription,CN=Domain System Volume,CN=DFSR-LocalSettings,CN=" & strDomainController & ",OU=Domain Controllers," & strDN)                              
    objSysvol.Put "msDFSR-RootPath", strNewSysvolPath & "\domain"
    objSysvol.Put "msDFSR-StagingPath", strNewSysvolPath & "\staging\domain"
    objSysvol.SetInfo

    Set objSysvol = Nothing
End If
