@Echo Off

REM Automated by Shaun Vermaak {22E1AA44-6A30-4e11-9F6E-45CD0A627B5E} downloaded from ITtelligence.co.za
REM Move Sysvol location (as per https://technet.microsoft.com/en-us/library/cc816594(v=ws.10).aspx)
REM The following must be in working folder or in path:
REM MoveSysvol.bat
REM SetDFSR.vbs
REM sysvol.inf
REM Usage: MoveSysvol.bat OLDSYSVOLPATH NEWSYSVOLPATH DOMAINFQDN
REM Example: MoveSysvol.bat C:\Windows\SYSVOL D:\SYSVOL TESTDOMAIN.COM

ECHO ### Change the SYSVOL Root Path or Staging Areas Path ###
cscript //nologo SetDFSR.vbs /DomainController:%COMPUTERNAME% /NewSysvolPath:%2 /FQDN:%3

ECHO ### Stop the DFS Replication Service and Netlogon Service ###
sc config DFSR start= Disabled
net stop DFSR

sc config netlogon start= Disabled
net stop netlogon

ECHO ### Copy SYSVOL to a New Location ###
robocopy "%1" "%2" /copyall /mir /b /r:0 /xd "DfsrPrivate" "%3" /xf "DfsrPrivate"

md "%2\staging"
md "%2\staging areas"

ECHO ### Change the SYSVOL Netlogon Parameters ###
REG ADD "HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" /v SysVol /d "%2\sysvol" /t REG_SZ /f
REG ADD "HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" /v SysvolReady /d 0 /t REG_DWORD /f

ECHO ### Reapply Default SYSVOL Security Settings ###
Set Sysvol=%2

Copy sysvol.inf %systemroot%\security\templates
secedit /configure /cfg %systemroot%\security\templates\sysvol.inf /db %systemroot%\security\templates\sysvol.db /overwrite /quiet

ECHO ### Create the SYSVOL Root and Staging Areas Junction Point ###
mklink /J "%2\sysvol\%3" "%2\domain"
mklink /J "%2\staging areas\%3" "%2\staging\domain"

ECHO ### Start the DFS Replication Service and Netlogon Service ###
sc config DFSR start= Auto
net start DFSR

sc config Netlogon start= Auto
net start Netlogon

REG ADD "HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" /v SysvolReady /d 1 /t REG_DWORD /f

net stop NTDS /y
net start NTDS
