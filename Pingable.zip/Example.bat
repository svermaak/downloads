@ECHO OFF
ECHO PINGABLE.EXE Example
ECHO.

Pingable.exe %1 4000 1

echo.
echo Errorlevel: %ERRORLEVEL%

if %ERRORLEVEL%==0 goto ONLINE

goto OFFLINE

:OFFLINE
ECHO Host not pingable.
GOTO THEEND

:ONLINE
ECHO Host pingable
GOTO THEEND

:THEEND
ECHO Done.
ECHO.