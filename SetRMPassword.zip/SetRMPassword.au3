#NoTrayIcon

$WINDIR = EnvGet("WINDIR")

If $CMDLINE[0] = 1 Then
    If FileExists($WINDIR & "\system32\ntdsutil.exe") Then
	    Run("ntdsutil.exe")
	    WinWaitActive($WINDIR & "\system32\ntdsutil.exe")
	    Send("set dsrm password{Enter}")
	    Send("reset password on server Null{Enter}")
    	Send($CMDLINE[1] & "{Enter}")
    	Send($CMDLINE[1] & "{Enter}")
    	Send("quit{Enter}")
    	Send("quit{Enter}")
    	MsgBox(4096, "SetRMPassword", "Done", 10)
		exit(0)
    Else
	    MsgBox(4096, "SetRMPassword", "Ntdsutil.exe does not exist", 10)
		exit(1)
    EndIf
Else
	MsgBox(4096, "SetRMPassword", "Usage: SetREPassword.exe PASSWORD", 10)
EndIf

