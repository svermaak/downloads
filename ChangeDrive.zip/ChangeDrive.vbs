Option Explicit

Dim objWMIService
Dim objFileSystemObject
Dim colVolumes
Dim objVolume

Set objWMIService = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")
Set objFileSystemObject = CreateObject("Scripting.FileSystemObject")

Set colVolumes = objWMIService.ExecQuery("Select * from Win32_Volume")
For Each objVolume in colVolumes
    If objFileSystemObject.FileExists(objVolume.DriveLetter & "\72821acd-379a-478a-a2c6-1ebd72cbead5.txt") Then
        objVolume.DriveLetter = "M:"
        objVolume.Put_
    End If
Next
