﻿using log4net;
using log4net.Config;
using System;
using System.Timers;

namespace $safeprojectname$
{
    public class MyService
    {
        // Setup log4net logger
        private static readonly ILog _log = LogManager.GetLogger(typeof(MyService));

        // The timer that triggers the event
        private Timer _heartbeatTimer = new Timer();

        // Boolean to determine if trigger should reoccur
        private volatile bool _requestServiceStop = false;

        // Interval that event should be triggered at
        private readonly long _heartbeatInterval = 10;

        public MyService()
        {
            // Configure log4net from app.config file
            XmlConfigurator.Configure();
            // Set the timer interval
            _heartbeatTimer.Interval = _heartbeatInterval * 1000;
            // Set the event that should be triggered
            _heartbeatTimer.Elapsed += OnTimedEvent;
            // Important! We do not want the event to reoccur unless on trigger has finished
            _heartbeatTimer.AutoReset = false;
            // Start event
            _heartbeatTimer.Start();
        }

        public void Start()
        {
            // Event should not stop the timer
            _requestServiceStop = false;
            // Start event
            _heartbeatTimer.Start();
        }

        public void Stop()
        {
            // Event should stop the timer
            _requestServiceStop = true;
            // Stop event
            _heartbeatTimer.Stop();
        }

        private void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            // Log heartbeat message
            _log.Info($"Heartbeat\t{DateTime.Now}");

            // Put code here

            // Start timer again if no request to stop recieved
            if (!_requestServiceStop)
            {
                _heartbeatTimer.Start();
            }
        }
    }
}