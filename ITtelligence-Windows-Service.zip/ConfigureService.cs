﻿using log4net.Config;
using Topshelf;

namespace $safeprojectname$
{
    internal static class ConfigureService
    {
        internal static void Configure()
        {
            // Configure log4net from app.config file
            XmlConfigurator.Configure();

            // Service configuration
            HostFactory.Run(configure =>
            {
                configure.Service<MyService>(service =>
                {
                    service.ConstructUsing(s => new MyService());
                    service.WhenStarted(s => s.Start());
                    service.WhenStopped(s => s.Stop());
                });

                // Set account that window service use to run.
                configure.RunAsLocalSystem();

                // Set service to the log4net
                configure.UseLog4Net();

                // Service text
                configure.SetServiceName("Put your service name here");
                configure.SetDisplayName("Put your service display name here");
                configure.SetDescription("Put your service description here");
            });
        }
    }
}