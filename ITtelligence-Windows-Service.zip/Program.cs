﻿namespace $safeprojectname$
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Start Windows Service
            ConfigureService.Configure();
        }
    }
}