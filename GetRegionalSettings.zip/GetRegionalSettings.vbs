'GetRegionalSettings v1.00 by Shaun Vermaak {22E1AA44-6A30-4e11-9F6E-45CD0A627B5C}")

Option Explicit

On Error Resume Next

Const HKEY_CURRENT_USER = &H80000001
Const HKEY_LOCAL_MACHINE = &H80000002
Const HKEY_USERS = &H80000003

Dim strComputer
Dim objReg
Dim strKeyPath
Dim strValueName
Dim strValue

strComputer = Wscript.Arguments.Named("Computer")

If Len(Trim(strComputer)) > 0 Then
    Set objReg = GetObject("winmgmts:{impersonationLevel=impersonate}!\\" & strComputer & "\root\default:StdRegProv")
    strKeyPath = ".DEFAULT\Control Panel\International"
    strValueName = "sCountry"
    objReg.GetStringValue HKEY_USERS,strKeyPath,strValueName,strValue
    Set objReg = Nothing

    Wscript.Echo strComputer & vbTab & strValue
Else
    Wscript.Echo "Usage: CCSRIPT.exe //NOLOGO /Computer:HOSTNAME
End If
