Option Explicit

On Error Resume Next

Dim strComputer
Dim strServiceName
Dim objComputer
Dim objService

strComputer = Wscript.Arguments.Named("Computer")
strServiceName = Wscript.Arguments.Named("ServiceName")

If Len(Trim(strComputer)) > 0 And Len(Trim(strServiceName)) > 0 Then
    If IsOnline(strComputer) = True Then
        Set objComputer = GetObject("WinNT://" & strComputer & ",computer")

        If Err.Number = 0 Then
            Set objService = objComputer.GetObject("service", strServiceName)

            If Err.Number = 0 Then
                WScript.Echo strComputer & vbTab & "Services Status" & vbTab & "Exists"
            Else
                WScript.Echo strComputer & vbTab & "Services Status" & vbTab & "Does not exist"
            End If
        Else
            WScript.Echo strComputer & vbTab & "Services Status" & vbTab & "Unknown"
        End If
    Else
        WScript.Echo strComputer & vbTab & "Services Status" & vbTab & "Offline"
    End If
Else
    WScript.Echo "Usage: cscript.exe //nologo DoesServiceExist.vbs /Computer:HOSTNAME /ServiceName:SERVICENAME"
End If

Function IsOnline(strComputer)
    Dim objPing
    Dim objStatus

    Set objPing = GetObject("winmgmts:" & Chr(123) & "impersonationLevel=impersonate" & Chr(125) & "").ExecQuery("select * from Win32_PingStatus where address = '" & strComputer & "'")

    For Each objStatus in objPing
        If IsNull(objStatus.StatusCode) or objStatus.StatusCode<>0 Then
            'Nothing
        Else
            IsOnline = True
        End If
    Next
End Function